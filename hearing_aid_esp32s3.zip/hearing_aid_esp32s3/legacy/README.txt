Direct-wired variant (4 mics on the Pi's own I2S pins). Not used with the ESP32-S3 design; kept for reference. Use with: python3 run.py --alsa
