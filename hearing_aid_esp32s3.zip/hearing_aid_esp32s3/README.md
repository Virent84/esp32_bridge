# Smart Hearing Aid – ESP32-S3 + Raspberry Pi 5 (4-mic DOA + beamforming)

```
4× INMP441 ──I2S──> ESP32-S3 ──native USB (binary packets, 16 kHz × 4 ch)──> Raspberry Pi 5
                                                                              │
   ESP32Source → preprocess (DC/HPF, mic EQ) → STFT → noise reduction → GCC-PHAT (6 pairs)
   → SRP-PHAT DOA (2° grid, speech-gated) → MVDR / delay-and-sum beamformer → audio out
   → live dashboard :8080
```

* ESP32 firmware: `firmware/hearing_aid_esp32s3/hearing_aid_esp32s3.ino`
* Wiring (your pin table): `docs/WIRING.md`
* Algorithms (unchanged, validated by `tools/selftest.py`): `ha/dsp.py`, `ha/pipeline.py`
* Pi-side ESP32 reader: `ESP32Source` in `ha/audio_source.py`

> **Honest status.** The Pi side was tested end to end against `tools/fake_esp32.py`, which emits the exact same
> packets (including packet loss, garbage bytes and a 2-sample port offset): link check, offset detection, recording,
> offline DOA and the live dashboard all work. The **firmware has not been compiled or run on a real ESP32-S3**
> by me – expect to fix small compile/pin issues on first flash and tell me the error text if so.

---

## Step 1 – Wire it (see `docs/WIRING.md`)
GPIO4 = SCK net, GPIO15 → jumper → GPIO4, GPIO5 = WS net, GPIO16 → jumper → GPIO5, GPIO6 = SD of M1+M2,
GPIO7 = SD of M3+M4, L/R: M1, M3 → GND; M2, M4 → 3V3. All VDD on 3V3.

## Step 2 – Flash the ESP32-S3 (Arduino IDE)
1. Install **ESP32 board package 3.x** (Boards Manager → "esp32 by Espressif", version 3.0 or newer).
2. Tools → Board **ESP32S3 Dev Module**; **USB CDC On Boot: Enabled**; USB Mode: Hardware CDC and JTAG (default).
3. Open `firmware/hearing_aid_esp32s3/hearing_aid_esp32s3.ino`, Upload.
4. Move the cable to the **native "USB" port** and plug it into the Pi. Do not open the Serial Monitor (the stream is binary).

## Step 3 – Set up the Pi 5
```
unzip hearing_aid_esp32s3.zip && cd hearing_aid_esp32s3
bash install.sh            # installs python3-numpy/scipy/flask/serial (no venv, no pip), adds you to 'dialout'
sudo reboot                # or log out / in
```
Then: `lsusb | grep 303a` and `ls /dev/ttyACM*` must show the board.

## Step 4 – Test ladder (do these in order)
| # | Command | Pass criterion |
|---|---|---|
| 1 | `python3 tools/selftest.py` | prints `PASS` (DSP works on the Pi) |
| 2 | `python3 tools/esp32_check.py` and **clap 3–4× above the array centre** | no lost packets / CRC errors, 4 live mics, no clipping, all lags within ±1 |
| 3 | If it prints `set "port1_shift_samples": N` → put N in `config.json` (`esp32` section), repeat #2 | all six pair lags ≈ 0 |
| 4 | `python3 tools/esp32_record.py --seconds 10 --out data/mics4ch.wav` with a person talking on the M1 side | file written, 0 lost |
| 5 | `python3 tools/offline_wav.py data/mics4ch.wav --expect 0` | DOA ≈ 0° (M2 side ≈ 90°, M3 ≈ 180°, M4 ≈ 270°), small spread |
| 6 | Repeat #4–5 from 90°, 180°, 270° | errors < ~10° |
| 7 | `python3 run.py` → open `http://<pi-ip>:8080` | red arrow follows you, green beam follows the red arrow |
| 8 | `python3 run.py --playback` (headphones, low volume) | beamformed speech is audible |
| 9 | `sudo systemctl enable --now hearing-aid` | starts on boot (`journalctl -u hearing-aid -f`) |

If angles are mirrored or offset by a constant: fix `array.mic_angles_deg` (reverse order / add offset) or measure the real
`array.radius_m`. Compare `--method mvdr` and `--method das` in `offline_wav.py`; listen to `data/output/enhanced_audio.wav`.

## No ESP32 at hand?
```
python3 tools/fake_esp32.py --target 90 --shift 2 --drop 0.01 --claps     # prints e.g. /dev/pts/3
python3 tools/esp32_check.py --port /dev/pts/3
python3 run.py --esp32 /dev/pts/3
```
`python3 run.py --sim` runs the dashboard on a purely synthetic source; `python3 run.py --wav file.wav` replays a recording.

## Configuration (`config.json`)
* `source`: `esp32` (default) | `sim` | `alsa` (legacy, mics wired straight to the Pi – see `legacy/`).
* `esp32.port` (`auto` = Espressif USB 303a:xxxx or first `/dev/ttyACM*`), `esp32.skip_s` (mic start-up transient, 0.5 s),
  `esp32.port1_shift_samples` (alignment of M3/M4 vs M1/M2, from `esp32_check.py`), `esp32.gain_db` (digital input gain).
* `sample_rate` must equal the firmware's 16000 Hz.
* `array.radius_m`, `array.mic_angles_deg` – geometry; DOA accuracy depends on it.
* `doa.vad_margin_db` (lower = more sensitive speech detection), `doa.min_confidence`, `doa.band_hz`.
* `beamformer.method` `mvdr`|`das`, `diag_loading`, `max_slew_deg_per_s`, `hysteresis_deg`.
* `preprocess.nr_floor_db` (noise-reduction depth), `output.playback`, `output.gain_db`, `output.record_wav`.

## Serial packet format (ESP32 → Pi), little-endian
| bytes | field |
|---|---|
| 2 | magic `0xA55A` (on the wire `5A A5`) |
| 2 | `seq` (increments per packet; gaps = lost packets, filled with silence by the Pi) |
| 2 | `nframes` (128 = 8 ms) |
| 2 | `flags` bit0 I2S DMA overflow, bit1 USB buffer full (packet dropped) |
| nframes×4×2 | `int16` PCM, interleaved M1,M2,M3,M4 |
| 2 | CRC-16/CCITT-FALSE over `seq … pcm` |

## Troubleshooting
* **No `/dev/ttyACM0`:** cable is in the UART port or is charge-only; use the native USB port. `lsusb | grep 303a`.
* **Permission denied on the port:** `groups | grep dialout`; log out/in after `install.sh`.
* **`NO DATA from the ESP32` but port exists:** firmware not flashed, or "USB CDC On Boot" was not Enabled. Text `ERR …` lines
  (visible with `head -c 200 /dev/ttyACM0`) mean an I2S init failure on the ESP32.
* **A mic reads silent:** check its SD line (GPIO6 for M1/M2, GPIO7 for M3/M4), L/R pin level and 3V3. A silent M2/M4 usually
  means L/R is not tied to 3V3; a silent M1/M3, L/R is not tied to GND.
* **Only M3/M4 silent (or lags huge):** the jumpers GPIO15→GPIO4 and GPIO16→GPIO5 are missing.
* **Lost packets / `pi_overrun`:** use a short good cable and a Pi USB port directly (no hub); close other CPU-heavy work.
* **Angles wrong by a constant or mirrored:** see the test-ladder note above.
